/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: error.h,v 1.3 1998/02/03 14:28:23 dick Exp $
*/

extern void fatal(const char *msg);
