/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: percentages.h,v 1.4 2012-06-05 09:58:54 dick Exp $
*/

extern void add_to_percentages(struct run *r);
extern void Show_Percentages(void);
